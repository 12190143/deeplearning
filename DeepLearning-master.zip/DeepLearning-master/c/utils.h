#ifndef UTILS_H
#define UTILS_H

double uniform(double, double);
int binomial(int, double);
double sigmoid(double);

#endif
