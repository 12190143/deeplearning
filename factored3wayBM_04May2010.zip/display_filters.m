% visualize the visible-factor filters and the visible bias of
% a factored 3 way BM
%
% Marc'Aurelio Ranzato
% 4 May 2010

% NOTE: you need to load the parameters before calling this
% script; e.g. load ws_temp
warning off

[sa,ss]  = system('pwd');
expernr = ss(strfind(ss,'exper')+5:end-1);

filename = 'filters';

load /u/ranzato/code/3wayRBM/demo/mar3010/training_colorpatches_16x16_demo.mat % load inverse PCA transform
VFo = invpcatransf * VF;

% VISIBLE-FACTOR 
[nrv nrh] = size(VFo);
npr = sqrt(nrv/3); % assume input patch is square and with
                   % three color channels
npc = npr;
nr = floor(sqrt(nrh));
nc = ceil(nrh / nr);

coef = 127/max(abs(min(VFo(:))), abs(max(VFo(:)))); 
ff = zeros(npr,npc,3);
ofs = 1;
ima = zeros(ofs+nr*(ofs+npr),ofs+nc*(ofs+npc),3);
for cc = 1 : nrh
    ff = reshape(VFo(:,cc),npr,npc,3);
    ff = ff.*coef + 128;    
    ima(ofs + floor((cc-1)/nc)*(ofs+npr) + 1 : ofs + (1 + floor((cc-1)/nc))*(ofs+npr) - 1, ...
       ofs + mod(cc-1,nc)*(ofs+npc) + 1 : ofs + (1 + mod(cc-1,nc))*(ofs+npc) - 1,:) = ff;
end
imwrite(ima/255,[filename '_VF.png'])
figure(101)
image(ima/255)
axis off; axis square
title('VISIBLE-FACTOR FILTERS')

% VISIBLE BIAS
bias_viso = reshape(invpcatransf * bias_vis,16,16,3);
figure(103)
image((bias_viso-min(bias_viso(:)))/(max(bias_viso(:))-min(bias_viso(:))))
axis square
axis off
imwrite((bias_viso-min(bias_viso(:)))/(max(bias_viso(:))-min(bias_viso(:))), [filename '_biasvis.png'])
title('VISIBLE BIAS')
