# Factored 3-way BM training
# Refer to:
# M. Ranzato, A. Krizhevsky, G. Hinton, "Factored 3-Way Restricted Boltzmann Machines for Modeling Natural Images". AISTATS 2010 
#
# Marc'Aurelio Ranzato
# 1 August 2010

import sys
from pylab import *
import numpy as np
import cudamat as cmt
from scipy.io import loadmat, savemat
#import gpu_lock # put here you locking system package, if any
from ConfigParser import *

######################################################################
# compute the value of the free energy at a given input
# F = - sum log(1+exp(- .5 FH (VF data)^2 + bias_cov)) - bias_vis data 
# NOTE: FH is constrained to be positive 
# (in the paper the sign is negative but the sign in front of it is also flipped)
def compute_energy_factored3wayBM(data,vel,energy,VF,FH,bias_cov,bias_vis,t1,t2,t6,feat,featsq):
    ## potential
    # covariance contribution
    cmt.dot(VF.T, data, target = feat) # HxP (nr factors x nr samples)
    feat.mult(feat, target = featsq)   # HxP
    cmt.dot(FH.T,featsq, target = t1) # OxP (nr cov hiddens x nr samples)
    t1.mult(-0.5)
    t1.add_col_vec(bias_cov) # OxP
    cmt.exp(t1) # OxP
    t1.add(1, target = t2) # OxP
    cmt.log(t2)
    t2.mult(-1)
    t2.sum(axis=0,target=energy)
    # visible bias term
    data.mult_by_col(bias_vis, target = t6)
    t6.mult(-1) # DxP
    energy.add_sums(t6,  axis=0) # 1xP
    # kinetic
    vel.mult(vel, target = t6)
    energy.add_sums(t6, axis = 0, mult = .5)

#################################################################
# compute the derivative if the free energy at a given input
def compute_gradient_factored3wayBM(data,VF,FH,bias_cov,bias_vis,t1,t2,t3,feat,featsq,gradient):
    cmt.dot(VF.T, data, target = feat) # HxP 
    feat.mult(feat, target = featsq)   # HxP
    cmt.dot(FH.T,featsq, target = t1) # OxP
    t1.mult(-.5)
    t1.add_col_vec(bias_cov) # OxP
    t1.apply_sigmoid(target = t2) # OxP
    cmt.dot(FH,t2, target = t3) # HxP
    t3.mult(feat)
    cmt.dot(VF, t3, target = gradient) # VxP
    # add visible bias term
    gradient.add_col_mult(bias_vis, -1)

############################################################3
# Hybrid Monte Carlo sampler
def draw_HMC_samples(data,negdata,vel,gradient,new_energy,old_energy,VF,FH,bias_cov,bias_vis,hmc_step,hmc_step_nr,hmc_ave_rej,hmc_target_ave_rej,t1,t2,t3,t4,t5,t6,t7,thresh,feat,featsq,batch_size):
    vel.fill_with_randn()
    negdata.assign(data)
    compute_energy_factored3wayBM(negdata,vel,old_energy,VF,FH,bias_cov,bias_vis,t1,t2,t6,feat,featsq)
    compute_gradient_factored3wayBM(negdata,VF,FH,bias_cov,bias_vis,t1,t2,t3,feat,featsq,gradient)
    # half step
    vel.add_mult(gradient, -0.5*hmc_step)
    negdata.add_mult(vel,hmc_step)
    # full leap-frog steps
    for ss in range(hmc_step_nr - 1):
        ## re-evaluate the gradient
        compute_gradient_factored3wayBM(negdata,VF,FH,bias_cov,bias_vis,t1,t2,t3,feat,featsq,gradient)
        # update variables
        vel.add_mult(gradient, -hmc_step)
        negdata.add_mult(vel,hmc_step)
    # final half-step
    compute_gradient_factored3wayBM(negdata,VF,FH,bias_cov,bias_vis,t1,t2,t3,feat,featsq,gradient)
    vel.add_mult(gradient, -0.5*hmc_step)
    # compute new energy
    compute_energy_factored3wayBM(negdata,vel,new_energy,VF,FH,bias_cov,bias_vis,t1,t2,t6,feat,featsq)
    # rejecton
    old_energy.subtract(new_energy, target = thresh)
    cmt.exp(thresh)
    t4.fill_with_rand()
    t4.less_than(thresh)
    #    update negdata and rejection rate
    t4.mult(-1)
    t4.add(1) # now 1's detect rejections
    t4.sum(axis = 1, target = t5)
    t5.copy_to_host()
    rej = t5.numpy_array[0,0]/batch_size
    data.mult_by_row(t4, target = t6)
    negdata.mult_by_row(t4, target = t7)
    negdata.subtract(t7)
    negdata.add(t6)
    hmc_ave_rej = 0.9*hmc_ave_rej + 0.1*rej
    if hmc_ave_rej < hmc_target_ave_rej:
        hmc_step = min(hmc_step*1.01,0.25)
    else:
        hmc_step = max(hmc_step*0.99,.001)
    return hmc_step, hmc_ave_rej


######################################################
# factored3wayBM trainer: sweeps over the training set.
# For each batch of samples compute derivatives to update the parameters
# at the training samples and at the negative samples drawn calling HMC sampler.
def train_factored3wayBM():

    config = ConfigParser()
    config.read('input_configuration')

    verbose = config.getint('VERBOSITY','verbose')

    num_epochs = config.getint('MAIN_PARAMETER_SETTING','num_epochs')
    batch_size = config.getint('MAIN_PARAMETER_SETTING','batch_size')
    startFH = config.getint('MAIN_PARAMETER_SETTING','startFH')
    startwd = config.getint('MAIN_PARAMETER_SETTING','startwd')
    doPCD = config.getint('MAIN_PARAMETER_SETTING','doPCD')

    # model parameters
    num_fac = config.getint('MODEL_PARAMETER_SETTING','num_fac')
    num_hid =  config.getint('MODEL_PARAMETER_SETTING','num_hid')

    # load data
    data_file_name =  config.get('DATA','data_file_name')
    d = loadmat(data_file_name) # input in the format PxD (P vectorized samples with D dimensions)
    totnumcases = d["whitendata"].shape[0]
    d = d["whitendata"][0:floor(totnumcases/batch_size)*batch_size,:].copy() 
    totnumcases = d.shape[0]
    num_vis =  d.shape[1]
    num_batches = int(totnumcases/batch_size)
    dev_dat = cmt.CUDAMatrix(d.T) # VxP 

    # training parameters
    epsilon = config.getfloat('OPTIMIZER_PARAMETERS','epsilon')
    epsilonVF = 1*epsilon
    epsilonFH = 0.05*epsilon
    epsilonb = 0.05*epsilon
    weightcost_final =  config.getfloat('OPTIMIZER_PARAMETERS','weightcost_final')

    # HMC setting
    hmc_step_nr = config.getint('HMC_PARAMETERS','hmc_step_nr')
    hmc_step =  0.01
    hmc_target_ave_rej =  config.getfloat('HMC_PARAMETERS','hmc_target_ave_rej')
    hmc_ave_rej =  hmc_target_ave_rej

    # initialize weights
    VF = cmt.CUDAMatrix(np.array(0.02 * np.random.randn(num_vis, num_fac), dtype=np.float32, order='F')) # VxH
    FH = cmt.CUDAMatrix( np.array( np.eye(num_fac,num_hid), dtype=np.float32, order='F')  ) # HxO
    bias_cov = cmt.CUDAMatrix( np.array(2.0*np.ones((num_hid, 1)), dtype=np.float32, order='F') )
    bias_vis = cmt.CUDAMatrix( np.array(np.zeros((num_vis, 1)), dtype=np.float32, order='F') )

    # initialize variables to store derivatives 
    VFinc = cmt.CUDAMatrix( np.array(np.zeros((num_vis, num_fac)), dtype=np.float32, order='F'))
    FHinc = cmt.CUDAMatrix( np.array(np.zeros((num_fac, num_hid)), dtype=np.float32, order='F'))
    bias_covinc = cmt.CUDAMatrix( np.array(np.zeros((num_hid, 1)), dtype=np.float32, order='F'))
    bias_visinc = cmt.CUDAMatrix( np.array(np.zeros((num_vis, 1)), dtype=np.float32, order='F'))

    # initialize temporary storage
    data = cmt.CUDAMatrix( np.array(np.empty((num_vis, batch_size)), dtype=np.float32, order='F')) # VxP
    negdataini = cmt.CUDAMatrix( np.array(np.empty((num_vis, batch_size)), dtype=np.float32, order='F')) # VxP
    feat = cmt.CUDAMatrix( np.array(np.empty((num_fac, batch_size)), dtype=np.float32, order='F'))
    featsq = cmt.CUDAMatrix( np.array(np.empty((num_fac, batch_size)), dtype=np.float32, order='F'))
    negdata = cmt.CUDAMatrix( np.array(np.random.randn(num_vis, batch_size), dtype=np.float32, order='F'))
    old_energy = cmt.CUDAMatrix( np.array(np.zeros((1, batch_size)), dtype=np.float32, order='F'))
    new_energy = cmt.CUDAMatrix( np.array(np.zeros((1, batch_size)), dtype=np.float32, order='F'))
    gradient = cmt.CUDAMatrix( np.array(np.empty((num_vis, batch_size)), dtype=np.float32, order='F')) # VxP
    thresh = cmt.CUDAMatrix( np.array(np.zeros((1, batch_size)), dtype=np.float32, order='F'))
    vel = cmt.CUDAMatrix( np.array(np.random.randn(num_vis, batch_size), dtype=np.float32, order='F'))
    normVF = 1    
    
    # other temporary vars
    t1 = cmt.CUDAMatrix( np.array(np.empty((num_hid, batch_size)), dtype=np.float32, order='F'))
    t2 = cmt.CUDAMatrix( np.array(np.empty((num_hid, batch_size)), dtype=np.float32, order='F'))
    t3 = cmt.CUDAMatrix( np.array(np.empty((num_fac, batch_size)), dtype=np.float32, order='F'))
    t4 = cmt.CUDAMatrix( np.array(np.empty((1,batch_size)), dtype=np.float32, order='F'))
    t5 = cmt.CUDAMatrix( np.array(np.empty((1,1)), dtype=np.float32, order='F'))
    t6 = cmt.CUDAMatrix( np.array(np.empty((num_vis, batch_size)), dtype=np.float32, order='F'))
    t7 = cmt.CUDAMatrix( np.array(np.empty((num_vis, batch_size)), dtype=np.float32, order='F'))
    t8 = cmt.CUDAMatrix( np.array(np.empty((num_vis, num_fac)), dtype=np.float32, order='F'))
    t9 = cmt.CUDAMatrix( np.array(np.zeros((num_fac, num_hid)), dtype=np.float32, order='F'))
    t10 = cmt.CUDAMatrix( np.array(np.empty((1,num_fac)), dtype=np.float32, order='F'))
    t11 = cmt.CUDAMatrix( np.array(np.empty((1,num_hid)), dtype=np.float32, order='F'))

    # start training
    for epoch in range(num_epochs):

        print "Epoch " + str(epoch + 1)
    
        # anneal learning rates
        epsilonVFc    = epsilonVF/max(1,epoch/20)
        epsilonFHc    = epsilonFH/max(1,epoch/20)
        epsilonbc    = epsilonb/max(1,epoch/20)
        weightcost = weightcost_final

        if epoch <= startFH:
            epsilonFHc = 0 
        if epoch <= startwd:	
            weightcost = 0

        for batch in range(num_batches):

            # get current minibatch
            data = dev_dat.slice(batch*batch_size,(batch + 1)*batch_size) # DxP (nr dims x nr samples)

            ## compute positive sample derivatives
            # covariance part
            cmt.dot(VF.T, data, target = feat) # HxP (nr facs x nr samples)
            feat.mult(feat, target = featsq)   # HxP
            cmt.dot(FH.T,featsq, target = t1) # OxP (nr cov hiddens x nr samples)
            t1.mult(-0.5)
            t1.add_col_vec(bias_cov) # OxP
            t1.apply_sigmoid(target = t2) # OxP
            cmt.dot(featsq, t2.T, target = FHinc) # HxO
            cmt.dot(FH,t2, target = t3) # HxP
            t3.mult(feat)
            cmt.dot(data, t3.T, target = VFinc) # VxH
            t2.sum(axis = 1, target = bias_covinc)
            bias_covinc.mult(-1)  
            # visible bias
            data.sum(axis = 1, target = bias_visinc)
            bias_visinc.mult(-1)
            
            # HMC sampling: draw an approximate sample from the model
            if doPCD == 0: # CD-1 (set negative data to current training samples)
                hmc_step, hmc_ave_rej = draw_HMC_samples(data,negdata,vel,gradient,new_energy,old_energy,VF,FH,bias_cov,bias_vis,hmc_step,hmc_step_nr,hmc_ave_rej,hmc_target_ave_rej,t1,t2,t3,t4,t5,t6,t7,thresh,feat,featsq,batch_size)
            else: # PCD-1 (use previous negative data as starting point for the chain)
                negdataini.assign(negdata)
                hmc_step, hmc_ave_rej = draw_HMC_samples(negdataini,negdata,vel,gradient,new_energy,old_energy,VF,FH,bias_cov,bias_vis,hmc_step,hmc_step_nr,hmc_ave_rej,hmc_target_ave_rej,t1,t2,t3,t4,t5,t6,t7,thresh,feat,featsq,batch_size)
                
            # compute derivatives at the negative samples
            # covariance part
            cmt.dot(VF.T, negdata, target = feat) # HxP 
            feat.mult(feat, target = featsq)   # HxP
            cmt.dot(FH.T,featsq, target = t1) # OxP
            t1.mult(-0.5)
            t1.add_col_vec(bias_cov) # OxP
            t1.apply_sigmoid(target = t2) # OxP
            FHinc.subtract_dot(featsq, t2.T) # HxO
            FHinc.mult(0.5)
            cmt.dot(FH,t2, target = t3) # HxP
            t3.mult(feat)
            VFinc.subtract_dot(negdata, t3.T) # VxH
            bias_covinc.add_sums(t2, axis = 1)
            # visible bias
            bias_visinc.add_sums(negdata, axis = 1)

            # update parameters
            VFinc.add_mult(VF.sign(), weightcost) # L1 regularization
            VF.add_mult(VFinc, -epsilonVFc/batch_size)
            # normalize columns of VF: normalize by running average of their norm             
            VF.mult(VF, target = t8)
            t8.sum(axis = 0, target = t10)
            cmt.sqrt(t10)
            t10.sum(axis=1,target = t5)
            t5.copy_to_host()
            normVF = .95*normVF + (.05/num_fac) * t5.numpy_array[0,0] # estimate norm
            t10.reciprocal()
            VF.mult_by_row(t10) 
            VF.mult(normVF) 
            
            bias_cov.add_mult(bias_covinc, -epsilonbc/batch_size)
            bias_vis.add_mult(bias_visinc, -epsilonbc/batch_size)

            if epoch > startFH:
                FHinc.add_mult(FH.sign(), weightcost) # L1 regularization
       		FH.add_mult(FHinc, -epsilonFHc/batch_size) # update
	        # set to 0 negative entries in FH
        	FH.greater_than(0, target = t9)
	        FH.mult(t9)
		# normalize columns of FH: L1 norm set to 1 in each column
		FH.sum(axis = 0, target = t11)               
		t11.reciprocal()
		FH.mult_by_row(t11) 

        if verbose == 1:
            print "VF: " + '%3.2e' % VF.euclid_norm() + ", DVF: " + '%3.2e' % (VFinc.euclid_norm()*(epsilonVFc/batch_size)) + ", FH: " + '%3.2e' % FH.euclid_norm() + ", DFH: " + '%3.2e' % (FHinc.euclid_norm()*(epsilonFHc/batch_size)) + ", bias_cov: " + '%3.2e' % bias_cov.euclid_norm() + ", Dbias_cov: " + '%3.2e' % (bias_covinc.euclid_norm()*(epsilonbc/batch_size)) + ", bias_vis: " + '%3.2e' % bias_vis.euclid_norm() + ", Dbias_vis: " + '%3.2e' % (bias_visinc.euclid_norm()*(epsilonbc/batch_size)) + ", step: " + '%3.2e' % hmc_step  +  ", rej: " + '%3.2e' % hmc_ave_rej 
            sys.stdout.flush()
        # back-up every once in a while 
        if np.mod(epoch,10) == 0:
            VF.copy_to_host()
            FH.copy_to_host()
            bias_cov.copy_to_host()
            bias_vis.copy_to_host()
            savemat("ws_temp", {'VF':VF.numpy_array,'FH':FH.numpy_array,'bias_cov': bias_cov.numpy_array, 'bias_vis': bias_vis.numpy_array, 'epoch':epoch})    
    # final back-up
    VF.copy_to_host()
    FH.copy_to_host()
    bias_cov.copy_to_host()
    bias_vis.copy_to_host()
    negdata.copy_to_host()
    savemat("ws_fac" + str(num_fac) + "_hid" + str(num_hid), {'VF':VF.numpy_array,'FH':FH.numpy_array,'bias_cov': bias_cov.numpy_array, 'bias_vis': bias_vis.numpy_array, 'negdata':negdata.numpy_array, 'epoch':epoch})



###################################33
# main
if __name__ == "__main__":
  # initialize CUDA
  #cmt.cuda_set_device(gpu_lock.obtain_lock_id()) # uncomment if you have a locking system 
  cmt.cublas_init()
  cmt.CUDAMatrix.init_random(1)
  train_factored3wayBM()
  cmt.cublas_shutdown()








