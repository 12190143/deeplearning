# How to

## Re-generate API documentation

To regenerate API documentation, run this commands from main git folder:

    cd scripts/docs
    ./gen_docs.sh

Then review and commit changes.

